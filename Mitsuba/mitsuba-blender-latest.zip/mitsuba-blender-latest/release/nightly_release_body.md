This release contains the latest commited changes of the Mitsuba-Blender add-on.

* [Changelog](https://github.com/mitsuba-renderer/mitsuba-blender/commits/master)
* [Report a bug](https://github.com/mitsuba-renderer/mitsuba-blender/issues/new/choose)

> :warning: This version is experimental and can be unstable, use at your own risk.
